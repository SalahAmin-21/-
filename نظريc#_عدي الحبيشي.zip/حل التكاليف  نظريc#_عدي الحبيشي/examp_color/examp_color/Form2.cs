﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace examp_color
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void RadioButton1red_CheckedChanged(object sender, EventArgs e)
        {
            
            if(radioButton1red.Checked)
            {
                label1color.BackColor = Color.Red;
                label1color.Text = "Red";
            }
        }

        private void RadioButton2blue_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2blue.Checked)
            {
                label1color.BackColor = Color.Blue;
                label1color.Text = "Blue";
            }
        }

        private void RadioButton3green_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3green.Checked)
            {
                label1color.BackColor = Color.Green;
                label1color.Text = "Green";

            }
        }

        private void RadioButton4white_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4white.Checked)
            {
                label1color.BackColor = Color.White;
                label1color.Text = "White";

            }
        }

        private void RadioButton5yellow_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5yellow.Checked)
            {
                label1color.BackColor = Color.Yellow;
                label1color.Text = "Yellow";

            }
        }

        private void RadioButton6black_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton6black.Checked)
            {
                label1color.BackColor = Color.Black;
                label1color.Text = "Black";

            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1color.Width = 600;
            label1color.Height = 300;
        }
    }
}
