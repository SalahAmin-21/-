﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_HW_Jubran
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();

        }
        int dx = 5;
        private void Timer1_Tick(object sender, EventArgs e)
        {
            label1.Left += dx;
            if(label1.Right>=this.ClientSize.Width||label1.Left<=0)
            {
                dx = -dx;
            }

        }

        private void Button2next_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            this.Hide();
        }
    }
}
