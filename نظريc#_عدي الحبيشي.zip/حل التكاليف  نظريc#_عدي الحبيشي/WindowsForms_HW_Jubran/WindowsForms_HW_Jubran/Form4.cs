﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_HW_Jubran
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        int pos = 0;
        string titel =  "  اهلا بك في برنامجنا المتحرك  !";
        private void Timer1_Tick(object sender, EventArgs e)
        {
            this.Text = titel.Substring(pos) + titel.Substring(0, pos);
            pos++;
            if (pos >= titel.Length) pos = 0;

        }

        private void Button2next_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
