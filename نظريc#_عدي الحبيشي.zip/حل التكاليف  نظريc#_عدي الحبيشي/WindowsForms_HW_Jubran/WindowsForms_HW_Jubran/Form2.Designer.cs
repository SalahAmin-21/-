﻿namespace WindowsForms_HW_Jubran
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.listBox1input = new System.Windows.Forms.ListBox();
            this.button1addlist = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button2next = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(389, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "التكليف رقم 2";
            // 
            // listBox1input
            // 
            this.listBox1input.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.listBox1input.FormattingEnabled = true;
            this.listBox1input.ItemHeight = 28;
            this.listBox1input.Location = new System.Drawing.Point(326, 120);
            this.listBox1input.Name = "listBox1input";
            this.listBox1input.Size = new System.Drawing.Size(288, 228);
            this.listBox1input.TabIndex = 1;
            // 
            // button1addlist
            // 
            this.button1addlist.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button1addlist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1addlist.Location = new System.Drawing.Point(254, 390);
            this.button1addlist.Name = "button1addlist";
            this.button1addlist.Size = new System.Drawing.Size(432, 65);
            this.button1addlist.TabIndex = 2;
            this.button1addlist.Text = " اظهار الاسم البرمجي في القائمه";
            this.button1addlist.UseVisualStyleBackColor = false;
            this.button1addlist.Click += new System.EventHandler(this.Button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(21, 529);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(271, 29);
            this.label2.TabIndex = 3;
            this.label2.Text = "عدي عبدالحميد الحبيشي";
            // 
            // button2next
            // 
            this.button2next.Location = new System.Drawing.Point(456, 529);
            this.button2next.Name = "button2next";
            this.button2next.Size = new System.Drawing.Size(419, 41);
            this.button2next.TabIndex = 4;
            this.button2next.Text = "الانتقال الى التكليف الثالث";
            this.button2next.UseVisualStyleBackColor = true;
            this.button2next.Click += new System.EventHandler(this.Button2next_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(938, 580);
            this.Controls.Add(this.button2next);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1addlist);
            this.Controls.Add(this.listBox1input);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox1input;
        private System.Windows.Forms.Button button1addlist;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2next;
    }
}