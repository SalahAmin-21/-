﻿namespace examp_color
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1color = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton1red = new System.Windows.Forms.RadioButton();
            this.radioButton2blue = new System.Windows.Forms.RadioButton();
            this.radioButton3green = new System.Windows.Forms.RadioButton();
            this.radioButton4white = new System.Windows.Forms.RadioButton();
            this.radioButton5yellow = new System.Windows.Forms.RadioButton();
            this.radioButton6black = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1color
            // 
            this.label1color.AutoSize = true;
            this.label1color.Location = new System.Drawing.Point(270, 87);
            this.label1color.Name = "label1color";
            this.label1color.Size = new System.Drawing.Size(62, 24);
            this.label1color.TabIndex = 0;
            this.label1color.Text = "Color";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton6black);
            this.groupBox1.Controls.Add(this.radioButton5yellow);
            this.groupBox1.Controls.Add(this.radioButton4white);
            this.groupBox1.Controls.Add(this.radioButton3green);
            this.groupBox1.Controls.Add(this.radioButton2blue);
            this.groupBox1.Controls.Add(this.radioButton1red);
            this.groupBox1.Location = new System.Drawing.Point(58, 160);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(503, 220);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "color";
            // 
            // radioButton1red
            // 
            this.radioButton1red.AutoSize = true;
            this.radioButton1red.Location = new System.Drawing.Point(15, 41);
            this.radioButton1red.Name = "radioButton1red";
            this.radioButton1red.Size = new System.Drawing.Size(71, 28);
            this.radioButton1red.TabIndex = 0;
            this.radioButton1red.TabStop = true;
            this.radioButton1red.Text = "Red";
            this.radioButton1red.UseVisualStyleBackColor = true;
            this.radioButton1red.CheckedChanged += new System.EventHandler(this.RadioButton1red_CheckedChanged);
            // 
            // radioButton2blue
            // 
            this.radioButton2blue.AutoSize = true;
            this.radioButton2blue.Location = new System.Drawing.Point(298, 41);
            this.radioButton2blue.Name = "radioButton2blue";
            this.radioButton2blue.Size = new System.Drawing.Size(76, 28);
            this.radioButton2blue.TabIndex = 1;
            this.radioButton2blue.TabStop = true;
            this.radioButton2blue.Text = "Blue";
            this.radioButton2blue.UseVisualStyleBackColor = true;
            this.radioButton2blue.CheckedChanged += new System.EventHandler(this.RadioButton2blue_CheckedChanged);
            // 
            // radioButton3green
            // 
            this.radioButton3green.AutoSize = true;
            this.radioButton3green.Location = new System.Drawing.Point(15, 103);
            this.radioButton3green.Name = "radioButton3green";
            this.radioButton3green.Size = new System.Drawing.Size(92, 28);
            this.radioButton3green.TabIndex = 2;
            this.radioButton3green.TabStop = true;
            this.radioButton3green.Text = "Green";
            this.radioButton3green.UseVisualStyleBackColor = true;
            this.radioButton3green.CheckedChanged += new System.EventHandler(this.RadioButton3green_CheckedChanged);
            // 
            // radioButton4white
            // 
            this.radioButton4white.AutoSize = true;
            this.radioButton4white.Location = new System.Drawing.Point(298, 103);
            this.radioButton4white.Name = "radioButton4white";
            this.radioButton4white.Size = new System.Drawing.Size(91, 28);
            this.radioButton4white.TabIndex = 3;
            this.radioButton4white.TabStop = true;
            this.radioButton4white.Text = "White";
            this.radioButton4white.UseVisualStyleBackColor = true;
            this.radioButton4white.CheckedChanged += new System.EventHandler(this.RadioButton4white_CheckedChanged);
            // 
            // radioButton5yellow
            // 
            this.radioButton5yellow.AutoSize = true;
            this.radioButton5yellow.Location = new System.Drawing.Point(15, 160);
            this.radioButton5yellow.Name = "radioButton5yellow";
            this.radioButton5yellow.Size = new System.Drawing.Size(98, 28);
            this.radioButton5yellow.TabIndex = 4;
            this.radioButton5yellow.TabStop = true;
            this.radioButton5yellow.Text = "Yellow";
            this.radioButton5yellow.UseVisualStyleBackColor = true;
            this.radioButton5yellow.CheckedChanged += new System.EventHandler(this.RadioButton5yellow_CheckedChanged);
            // 
            // radioButton6black
            // 
            this.radioButton6black.AutoSize = true;
            this.radioButton6black.Location = new System.Drawing.Point(298, 160);
            this.radioButton6black.Name = "radioButton6black";
            this.radioButton6black.Size = new System.Drawing.Size(86, 28);
            this.radioButton6black.TabIndex = 5;
            this.radioButton6black.TabStop = true;
            this.radioButton6black.Text = "Black";
            this.radioButton6black.UseVisualStyleBackColor = true;
            this.radioButton6black.CheckedChanged += new System.EventHandler(this.RadioButton6black_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(111, 411);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(157, 35);
            this.button1.TabIndex = 2;
            this.button1.Text = "Bac_login";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(377, 411);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(126, 35);
            this.button2.TabIndex = 3;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(651, 516);
            this.Controls.Add(this.label1color);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1color;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton6black;
        private System.Windows.Forms.RadioButton radioButton5yellow;
        private System.Windows.Forms.RadioButton radioButton4white;
        private System.Windows.Forms.RadioButton radioButton3green;
        private System.Windows.Forms.RadioButton radioButton2blue;
        private System.Windows.Forms.RadioButton radioButton1red;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}